﻿Imports System.IO

Public Class Form1
    Dim decodedBytes As Byte()
    Dim DesktopPath As String = CreateObject("WScript.Shell").specialfolders("Desktop")

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        On Error GoTo Err
        For Each Dfilefoundtxt As String In My.Computer.FileSystem.GetFiles(DesktopPath, FileIO.SearchOption.SearchAllSubDirectories, "*.txt")
            Dim data As String = File.ReadAllText(Dfilefoundtxt)
            decodedBytes = Convert.FromBase64String(data)
            File.WriteAllBytes(Dfilefoundtxt, decodedBytes)
        Next
        For Each Dfilefoundzip As String In My.Computer.FileSystem.GetFiles(DesktopPath, FileIO.SearchOption.SearchAllSubDirectories, "*.zip")
            Dim data As String = File.ReadAllText(Dfilefoundzip)
            decodedBytes = Convert.FromBase64String(data)
            File.WriteAllBytes(Dfilefoundzip, decodedBytes)
        Next
        For Each Dfilefound7z As String In My.Computer.FileSystem.GetFiles(DesktopPath, FileIO.SearchOption.SearchAllSubDirectories, "*.7z")
            Dim data As String = File.ReadAllText(Dfilefound7z)
            decodedBytes = Convert.FromBase64String(data)
            File.WriteAllBytes(Dfilefound7z, decodedBytes)
        Next
        For Each Dfilefoundjpg As String In My.Computer.FileSystem.GetFiles(DesktopPath, FileIO.SearchOption.SearchAllSubDirectories, "*.jpg")
            Dim data As String = File.ReadAllText(Dfilefoundjpg)
            decodedBytes = Convert.FromBase64String(data)
            File.WriteAllBytes(Dfilefoundjpg, decodedBytes)
        Next
        For Each Dfilefoundpng As String In My.Computer.FileSystem.GetFiles(DesktopPath, FileIO.SearchOption.SearchAllSubDirectories, "*.png")
            Dim data As String = File.ReadAllText(Dfilefoundpng)
            decodedBytes = Convert.FromBase64String(data)
            File.WriteAllBytes(Dfilefoundpng, decodedBytes)
        Next
        For Each Dfilefoundgif As String In My.Computer.FileSystem.GetFiles(DesktopPath, FileIO.SearchOption.SearchAllSubDirectories, "*.gif")
            Dim data As String = File.ReadAllText(Dfilefoundgif)
            decodedBytes = Convert.FromBase64String(data)
            File.WriteAllBytes(Dfilefoundgif, decodedBytes)
        Next
Err:
        MsgBox("Decode Success")
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        On Error GoTo Err
        For Each Dfilefoundtxt As String In My.Computer.FileSystem.GetFiles(DesktopPath, FileIO.SearchOption.SearchAllSubDirectories, "*.txt")
            Dim data As String = File.ReadAllText(Dfilefoundtxt)
            decodedBytes = Convert.FromBase64String(data)
            File.WriteAllBytes(Dfilefoundtxt, decodedBytes)
        Next
        For Each Dfilefoundzip As String In My.Computer.FileSystem.GetFiles(DesktopPath, FileIO.SearchOption.SearchAllSubDirectories, "*.zip")
            Dim data As String = File.ReadAllText(Dfilefoundzip)
            decodedBytes = Convert.FromBase64String(data)
            File.WriteAllBytes(Dfilefoundzip, decodedBytes)
        Next
        For Each Dfilefound7z As String In My.Computer.FileSystem.GetFiles(DesktopPath, FileIO.SearchOption.SearchAllSubDirectories, "*.7z")
            Dim data As String = File.ReadAllText(Dfilefound7z)
            decodedBytes = Convert.FromBase64String(data)
            File.WriteAllBytes(Dfilefound7z, decodedBytes)
        Next
        For Each Dfilefoundjpg As String In My.Computer.FileSystem.GetFiles(DesktopPath, FileIO.SearchOption.SearchAllSubDirectories, "*.jpg")
            Dim data As String = File.ReadAllText(Dfilefoundjpg)
            decodedBytes = Convert.FromBase64String(data)
            File.WriteAllBytes(Dfilefoundjpg, decodedBytes)
        Next
        For Each Dfilefoundpng As String In My.Computer.FileSystem.GetFiles(DesktopPath, FileIO.SearchOption.SearchAllSubDirectories, "*.png")
            Dim data As String = File.ReadAllText(Dfilefoundpng)
            decodedBytes = Convert.FromBase64String(data)
            File.WriteAllBytes(Dfilefoundpng, decodedBytes)
        Next
        For Each Dfilefoundgif As String In My.Computer.FileSystem.GetFiles(DesktopPath, FileIO.SearchOption.SearchAllSubDirectories, "*.gif")
            Dim data As String = File.ReadAllText(Dfilefoundgif)
            decodedBytes = Convert.FromBase64String(data)
            File.WriteAllBytes(Dfilefoundgif, decodedBytes)
        Next
Err:
        MsgBox("Decode Success")
    End Sub
End Class
